import React from 'react';
import axios from 'axios';

export default function NoteList({ notes, refresh }) {
  const togglePin = async (id, pinned) => {
    await axios.put(`http://localhost:5000/notes/${id}`, { pinned: !pinned });
    refresh();
  };

  const toggleArchive = async (id, archived) => {
    await axios.put(`http://localhost:5000/notes/${id}`, { archived: !archived });
    refresh();
  };

  const deleteNote = async (id) => {
    await axios.delete(`http://localhost:5000/notes/${id}`);
    refresh();
  };

  return (
    <div className="space-y-4">
      {notes.map(note => (
        <div key={note._id} className="bg-white p-4 shadow rounded">
          <h2 className="font-bold text-lg">{note.title}</h2>
          <div dangerouslySetInnerHTML={{ __html: note.content }} />
          <p className="text-sm text-gray-600">Tags: {note.tags.join(', ')}</p>
          <div className="mt-2 flex gap-2">
            <button onClick={() => togglePin(note._id, note.pinned)} className="px-2 py-1 bg-yellow-400 rounded">
              {note.pinned ? 'Unpin' : 'Pin'}
            </button>
            <button onClick={() => toggleArchive(note._id, note.archived)} className="px-2 py-1 bg-purple-400 rounded">
              {note.archived ? 'Unarchive' : 'Archive'}
            </button>
            <button onClick={() => deleteNote(note._id)} className="px-2 py-1 bg-red-500 text-white rounded">Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}
