import React, { useState } from 'react';
import axios from 'axios';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

export default function NoteForm({ refresh }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/notes', {
      title,
      content,
      tags: tags.split(',').map(t => t.trim())
    });
    setTitle('');
    setContent('');
    setTags('');
    refresh();
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow rounded p-4 mb-4">
      <input
        className="border p-2 w-full mb-2"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <ReactQuill value={content} onChange={setContent} className="mb-2" />
      <input
        className="border p-2 w-full mb-2"
        placeholder="Tags (comma separated)"
        value={tags}
        onChange={(e) => setTags(e.target.value)}
      />
      <button className="bg-green-500 text-white px-4 py-2 rounded" type="submit">Add Note</button>
    </form>
  );
}
