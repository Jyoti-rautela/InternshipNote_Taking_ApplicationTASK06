import React, { useEffect, useState } from 'react';
import axios from 'axios';
import NoteForm from './components/NoteForm';
import NoteList from './components/NoteList';

export default function App() {
  const [notes, setNotes] = useState([]);
  const [search, setSearch] = useState('');

  const fetchNotes = async () => {
    const res = await axios.get(`http://localhost:5000/notes?search=${search}`);
    setNotes(res.data);
  };

  useEffect(() => { fetchNotes(); }, [search]);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Notes App</h1>
      <div className="mb-4 flex gap-2">
        <input
          type="text"
          placeholder="Search notes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border rounded p-2 flex-1"
        />
        <button onClick={fetchNotes} className="bg-blue-500 text-white px-4 py-2 rounded">Search</button>
      </div>
      <NoteForm refresh={fetchNotes} />
      <NoteList notes={notes} refresh={fetchNotes} />
    </div>
  );
}
